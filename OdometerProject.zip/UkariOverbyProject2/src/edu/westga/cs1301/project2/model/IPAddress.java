package edu.westga.cs1301.project2.model;



public class IPAddress {
	private int quartetOne;
	private int quartetTwo;
	private int quartetThree;
	private int quartetFour;
	
	
	
	/** Gets the first quartet.
	 * 
	 * @precondition none.
	 * @postcondition none.
	 * 
	 * @return the first quartet.
	 */
	public int getQuartetOne() {
		return this.quartetOne;
	}


	/** Gets the first quartet.
	 * 
	 * @precondition none.
	 * @precondition none.
	 * 
	 * @return the second quartet.
	 */
	public int getQuartetTwo() {
		return this.quartetTwo;
	}


	/** Gets the third quartet.
	 * 
	 * @precondition none.
	 * @postcondition none.
	 * 
	 * @return the third quartet.
	 */
	public int getQuartetThree() {
		return this.quartetThree;
	}


	/** Gets the fourth quartet.
	 * 
	 * @precondition none.
	 * @postcondition none.
	 * 
	 * @return the fourth quartet.
	 */
	public int getQuartetFour() {
		return this.quartetFour;
	}
	
	/** Creates an IP address object at 0.0.0.0
	 * 
	 * @precondition none
	 * @postcondition getQuartetOne == 0 && getQuartetTwo == 0 && getQuartetThree == 0
	 *                  && getQuartetFour == 0
	 * 
	 */
	public IPAddress () {
		this.quartetOne = 0;
		this.quartetTwo = 0;
		this.quartetThree = 0;
		this.quartetFour = 0;
		
	}
	
	/** Creates an IP address object.
	 * 
	 * @precondition quartetOne <= 255 && quartetOne >= 0 && quartetTwo <= 255 && quartetTwo >= 0
	 *                 quartetThree <= 255 && quartetThree >= 0 && quartetFour <= 255 && quartetFour >= 0
	 * 
	 * @postcondition none
	 * 
	 */
	public IPAddress (int quartetOne, int quartetTwo, int quartetThree, int quartetFour) {
		if(quartetOne > 255) {
			throw new IllegalArgumentException("Quartet one must not be greater than 255.");
		}
		if(quartetOne < 0) {
			throw new IllegalArgumentException("Quartet one must not be negative.");
		}
		if(quartetTwo > 255) {
			throw new IllegalArgumentException("Quartet two must not be greater than 255.");
		}
		if(quartetTwo < 0) {
			throw new IllegalArgumentException("Quartet two must not be negative.");
		}
		if(quartetThree > 255) {
			throw new IllegalArgumentException("Quartet three must not be greater than 255.");
		}
		if(quartetThree < 0) {
			throw new IllegalArgumentException("Quartet three must not be negative.");
		}
		if(quartetFour > 255) {
			throw new IllegalArgumentException("Quartet four must not be greater than 255.");
		}
		if(quartetFour < 0) {
			throw new IllegalArgumentException("Quartet four must not be negative.");
		}
		
		this.quartetOne = quartetOne;
		this.quartetTwo = quartetTwo;
		this.quartetThree = quartetThree;
		this.quartetFour = quartetFour;
	}
	
	/**
	 * Increments quartet one by 1
	 * 
	 * @precondition	none
	 * @postcondition	getQuartetOne()==getQuartetOne()@prev+1 % 10
	 */
	public void incrementFirstQuartet() {
		this.quartetOne = (this.quartetOne + 1) % 256;
	}
	
	/**
	 * Increments quartet two by 1
	 * 
	 * @precondition	none
	 * @postcondition	getQuartetTwo()==getQuartetTwo()@prev+1 % 10
	 */
	public void incrementSecondQuartet() {
		this.quartetTwo = (this.quartetTwo + 1) % 256;
	}
	
	/**
	 * Increments quartet three by 1
	 * 
	 * @precondition	none
	 * @postcondition	getQuartetThree()==getQuartetThree()@prev+1 % 10
	 */
	public void incrementThirdQuartet() {
		this.quartetThree = (this.quartetThree + 1) % 256;
	}
	
	/**
	 * Increments quartet four by 1
	 * 
	 * @precondition	none
	 * @postcondition	getQuartetFour()==getQuartetFour()@prev+1 % 10
	 */
	public void incrementFourthQuartet() {
		this.quartetFour = (this.quartetFour + 1) % 256;
	}
	
	
	
	
}
