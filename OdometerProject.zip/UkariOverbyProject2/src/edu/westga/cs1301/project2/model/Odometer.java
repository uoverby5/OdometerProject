package edu.westga.cs1301.project2.model;

/**
 * Models an odometer with 3 dials
 *
 * @author	CS1301
 * @version	Spring 2022
 *
 */
public class Odometer {
	private int ones;
	private int tens;
	private int tenths;
	
	
	
	/**
	 * Creates an odometer at 00.0
	 * 
	 * @precondition	none
	 * @postcondition	getOnes()==0 AND
	 * 					getTens()==0
	 */
	public Odometer() {
		this.ones = 0;
		this.tens = 0;
		this.tenths = 0;
		
	}
	
	/** Creates an odometer object.
	 * 
	 * @precondition 0 <= this.tens <= 9 AND 0 <= this.ones <= 9
	 *                    && 0 <= this.tenths <= 9
	 * @postcondition
	 * 
	 */
	public Odometer(int ones, int tens, int tenths) {
		if (tens < 0 || tens > 9) {
			throw new IllegalArgumentException("tens digit must be between 0 and 9");
		}
		if (ones < 0 || ones > 9) {
			throw new IllegalArgumentException("ones digit must be between 0 and 9");
		}
		if(tenths < 0 || tenths > 9) {
			throw new IllegalArgumentException("tenths digit must be between 0 and 9");
		}
		
		this.ones = ones;
		this.tens = tens;
		this.tenths = tenths;
		
	}
	
	
	
	/**
	 * Creates an odometer at <tens><ones>
	 * 
	 * @precondition	0 <= this.tens <= 9 AND
	 * 					0 <= this.ones <= 9
	 * 
	 * @postcondition	getTens() == this.tens AND
	 * 					getOnes() == this.ones
	 * 
	 * @param tens		the value in the tens digit
	 * @param ones		the value in the ones digit
	 */
	public Odometer(int ones, int tens) {
		if (tens < 0 || tens > 9) {
			throw new IllegalArgumentException("tens digit must be between 0 and 9");
		}
		if (ones < 0 || ones > 9) {
			throw new IllegalArgumentException("ones digit must be between 0 and 9");
		}
		
		this.tens = tens;
		this.ones = ones;
	}
	
	/**
	 * Returns the value of the ones digit
	 * @precondition	none
	 * @postcondition	none
	 * @return	the value in the ones digit
	 */
	public int getOnes() {
		return this.ones;
	}
	
	/**
	 * Returns the value of the tens digit
	 * @precondition	none
	 * @postcondition	none
	 * @return	the value in the tens digit
	 */
	public int getTens() {
		return this.tens;
	}
	
	/** Gets the tenths.
	 * 
	 * @precondition none.
	 * @postcondition none.
	 * 
	 * @return the tenths
	 */
	public int getTenths() {
		return tenths;
	}
	
	/**
	 * Increments ones digit by 1
	 * 
	 * @precondition	none
	 * @postcondition	getOnes()==getOnes()@prev+1 % 10
	 */
	public void incrementOnes() {
		this.ones = (this.ones + 1) % 10;
	}
	
	/**
	 * Increments hundreds digit by 1
	 * 
	 * @precondition	none
	 * @postcondition	getTens()==getTens()@prev+1 % 10
	 */
	public void incrementTens() {
		this.tens = (this.tens + 1) % 10;
	}
	
	/** Increments tenths digit by 1.
	 * 
	 * @precondition none.
	 * @postcondition getTenths() == getTenths()@prev+1 % 10
	 */
	public void incrementTenths() {
		this.tenths = (this.tenths + 1) % 10;
	}
	
	/** Decrements ones digit by 1.
	 * 
	 * @precondition none.
	 * @postcondition getOnes() == getOnes()@prev-1 % 10
	 */
	public void decrementOnes() {
		this.ones = (this.ones - 1) % 10;
	}
	
	/** Decrements tens digit by 1.
	 * 
	 * @precondition none.
	 * @postcondition getTens() == getTens()@prev-1 % 10
	 */
	public void decrementTens() {
		this.tens = (this.tens - 1) % 10;
	}
	
	/** Decrements tenths digit by 1.
	 * 
	 * @precondition none.
	 * @postcondition getTenths() == getTenths()@prev-1 % 10
	 */
	public void decrementTenths() {
		this.tenths = (this.tenths - 1) % 10;
	}

	
}
