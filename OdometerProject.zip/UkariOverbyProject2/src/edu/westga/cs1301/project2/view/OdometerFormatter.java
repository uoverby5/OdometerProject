package edu.westga.cs1301.project2.view;

import edu.westga.cs1301.project2.model.Odometer;

/**
 * This class can be used to format an odometer
 * 
 * @author	CS1301
 * @version	Spring 2022
 *
 */
public class OdometerFormatter {
	
	/**
	 * Returns a String with the odometer formatted so that
	 *  it displays in the format:
	 *  	<tens><ones>.<tenths>
	 * 
	 * @precondition	theOdometer != null
	 * @postcondition	none
	 * @param			theOdometer	the odometer object to be formatted
	 * @return			a formatted odometer value
	 */
	public String formatOdometer(Odometer theOdometer) {
		if(theOdometer == null) {
			throw new IllegalArgumentException("The odometer must not be null.");
		}
		        
		
		String message = Integer.toString(theOdometer.getTens()) + Integer.toString(theOdometer.getOnes())
				+ "." + Integer.toString(theOdometer.getTenths());
		
		
		return message;
	}
}
