package edu.westga.cs1301.project2.view;

import edu.westga.cs1301.project2.model.IPAddress;
import edu.westga.cs1301.project2.model.Odometer;

public class IPAddressFormatter {
	
	/**
	 * Returns a String with the the address formatted so that
	 *  it displays in the format:
	 *  	0.0.0.0
	 * 
	 * @precondition	theAddress != null
	 * @postcondition	none
	 * @param			theAddress the address object to be formatted
	 * @return			a formatted address value
	 */
	public String formatIPAddress(IPAddress theAddress) {
		if(theAddress == null) {
			throw new IllegalArgumentException("The address must not be null.");
		}
		        
		
		String message = Integer.toString(theAddress.getQuartetOne()) + "." +
		Integer.toString(theAddress.getQuartetTwo()) + "." + Integer.toString(theAddress.getQuartetThree())
		+ "." + Integer.toString(theAddress.getQuartetFour());
				
		
		
		return message;
	}

}
