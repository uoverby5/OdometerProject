package edu.westga.cs1301.project2.controller;

import edu.westga.cs1301.project2.model.IPAddress;

public class IPAddressController {
	private IPAddress theAddress;

	/** Gets the IP address.
	 * 
	 * @precondition
	 * @postcondition
	 * 
	 * @return the IP theAddress
	 */
	public IPAddress getTheAddress() {
		return theAddress;
	}
	
	/** Creates an IP address object.
	 * 
	 * @precondition none.
	 * @postcondition 
	 * 
	 */
	public IPAddressController() {
		this.theAddress = new IPAddress();
	}
	
	
	/** Adds the given number to the first quartet.
	 * 
	 * @precondition number >= 0
	 * @postcondition 
	 * 
	 * @param number, number to be added to the first quartet.
	 * 
	 */
	public void addToFirstQuartet(int number) {
		if(number < 0) {
			throw new IllegalArgumentException("Number must not be negative.");
		}
		
		for(int i = 0; i < number; i++) {
			this.theAddress.incrementFirstQuartet();
			
			if(this.theAddress.getQuartetOne() == 0) {
				this.theAddress.incrementSecondQuartet();
			}
		}
	}
	
	/** Adds the given number to the second quartet.
	 * 
	 * @precondition number >= 0
	 * @postcondition 
	 * 
	 * @param number, number to be added to the second quartet.
	 * 
	 */
	public void addToSecondQuartet(int number) {
		if(number < 0) {
			throw new IllegalArgumentException("Number must not be negative.");
		}
		
		for(int i = 0; i < number; i++) {
			this.theAddress.incrementSecondQuartet();
			
			if(this.theAddress.getQuartetTwo() == 0) {
				this.theAddress.incrementThirdQuartet();
			}
			
		}
	}

	

}
