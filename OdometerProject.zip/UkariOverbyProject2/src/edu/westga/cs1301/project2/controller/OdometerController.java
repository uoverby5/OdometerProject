package edu.westga.cs1301.project2.controller;

import edu.westga.cs1301.project2.model.Odometer;

/**
 * Controller for the odometer application
 * 
 * @author	CS1301
 * @version	Spring 2022
 *
 */
public class OdometerController {
	private Odometer theOdometer;
	 
	
	/**
	 * Creates a new OdometerController containing an Odometer
	 * 
	 * @precondition	none
	 * @postcondition	getOdometer().getTenths()==0 AND
	 * 					getOdometer().getOnes()==0 AND
	 * 					getOdometer().getTens()==0
	 */
	public OdometerController() {
		this.theOdometer = new Odometer();
	}
		
	
	
	/** Gets the odometer object.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the odometer object.
	 */
	public Odometer getTheOdometer() {
		return this.theOdometer;
	}
	
	/** Adds the given number to the tens dial.
	 * 
	 * @precondition number >= 0
	 * @postcondition this.theOdometer.getTens() == this.theOdometer.getTens()@prev+number % 10
	 * 
	 * @param number, number to be added to the tens dial.
	 * 
	 */
	public void addToTens(int number) {
		if(number < 0) {
			throw new IllegalArgumentException("Number must not be negative.");
		}
		
		for(int i = 0; i < number; i++) {
			this.theOdometer.incrementTens();
		}
	}
	
	
	/** Adds the given number to the ones dial, incrementing the tens dial as needed.
	 * 
	 * @precondition number >= 0.
	 * @postcondition this.theOdometer.getOnes() == this.theOdometer.getOnes()@prev+number % 10
	 * 
	 * @param number, the number to be added to the ones dial.
	 * 
	 */
	public void addToOnes(int number) {
		if(number < 0) {
			throw new IllegalArgumentException("Number must not be negative.");
		}
		
		for(int i = 0; i < number; i++) {
			this.theOdometer.incrementOnes();
			
			if(this.theOdometer.getOnes() == 9) {
				this.theOdometer.incrementTens();
			}
		}
		
	}
	
	/** Adds the given number to the tenths dial.
	 * 
	 * @precondition number >= 0.
	 * @postcondition this.theOdometer.getOnes() == this.theOdometer.getOnes()@prev+number % 10
	 * 
	 * @param number, the number to be added to the ones dial.
	 * 
	 */
	public void addToTenths(int number) {
		if(number < 0) {
			throw new IllegalArgumentException("Number must not be less than 0.");
		}
		
		for(int i = 0; i < number; i++) {
			this.theOdometer.incrementTenths();
			
			if(this.theOdometer.getTenths() == 9) {
				this.theOdometer.incrementOnes();
				
				if(this.theOdometer.getOnes() == 9) {
					this.theOdometer.incrementTens();
				}
				
					}
				
						}
	}
	
	/** Subtracts the given number from the tens dial.
	 * 
	 * @precondition number >= 0
	 * @postcondition this.theOdometer.getTens() == this.theOdometer.getTens()@prev-number % 10
	 * 
	 * @param number, number to be added to the tens dial.
	 * 
	 */
	public void subtractFromTens(int number) {
		if(number < 0) {
			throw new IllegalArgumentException("Number must not be negative.");
		}
		
		for(int i = 0; i < number; i++) {
			this.theOdometer.decrementTens();
		}
	}

	

}
