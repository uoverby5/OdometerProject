package edu.westga.cs1301.project2.test.odometer;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import edu.westga.cs1301.project2.model.Odometer;

/**
 * Tests to confirm correct functionality of the 
 * 	Odometer::incrementOnes() method
 * 
 * @author	CS1301
 * @version	Spring 2022
 *
 */
public class TestIncrementOnes {

	@Test
	public void testShouldIncrementOnesFrom0() {
		// Arrange: create an Odometer with the appropriate ones dial
		Odometer theOdometer = new Odometer(0, 0);
		
		// Act: increment the ones dial
		theOdometer.incrementOnes();
		
		// Assert: that the actual value matches the expected value
		assertEquals(1, theOdometer.getOnes());
	}
	
	@Test
	public void testShouldIncrementOnesFrom4() {
		// Arrange: create an Odometer with the appropriate ones dial
		Odometer theOdometer = new Odometer(4, 0);
		
		// Act: increment the ones dial
		theOdometer.incrementOnes();
		
		// Assert: that the actual value matches the expected value
		assertEquals(5, theOdometer.getOnes());
	}
	
	@Test
	public void testShouldIncrementOnes12Times() {
		// Arrange: create an Odometer with the appropriate ones dial
		Odometer theOdometer = new Odometer(0, 0);
		
		// Act: increment the ones dial
		for (int counter = 0; counter < 12; counter++) {
			theOdometer.incrementOnes();
		}
		
		// Assert: that the actual value matches the expected value
		assertEquals(2, theOdometer.getOnes());
	}

}
