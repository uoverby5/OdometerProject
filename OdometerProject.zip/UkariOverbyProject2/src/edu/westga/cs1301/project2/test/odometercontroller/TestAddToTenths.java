package edu.westga.cs1301.project2.test.odometercontroller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.project2.controller.OdometerController;
import edu.westga.cs1301.project2.model.Odometer;

/**
 * Tests to confirm correct functionality of adding to the
 * 	odometer's tenths dial
 * 
 * @author	CS1301
 * @version	Spring 2022
 *
 */
public class TestAddToTenths {

	@Test
	public void testShouldNotAllowAddingNegativeNumber() {
		// Arrange: create a controller
		OdometerController theController = new OdometerController();
		
		// Act & Assert: call addToTenths with a negative value
		// and assert it throws an exception
		assertThrows(IllegalArgumentException.class, () -> {
			theController.addToTenths(-1);
		});
	}
	
	@Test
	public void testShouldAddZeroToTenths() {
		// Arrange: create a controller
		OdometerController theController = new OdometerController();
		
		// Act: call the method with an appropriate parameter
		theController.addToTenths(0);
		
		// Assert: that the dial has the expected value
		Odometer theOdometer = theController.getTheOdometer();
		assertEquals(0, theOdometer.getTenths());
	}
	
	@Test
	public void testShouldAddOneToTenths() {
		// Arrange: create a controller
		OdometerController theController = new OdometerController();
		
		// Act: call the method with an appropriate parameter
		theController.addToTenths(1);
		
		// Assert: that the dial has the expected value
		Odometer theOdometer = theController.getTheOdometer();
		assertEquals(1, theOdometer.getTenths());
	}
	
	@Test
	public void testShouldAddFourToTenths() {
		// Arrange: create a controller
		OdometerController theController = new OdometerController();
		
		// Act: call the method with an appropriate parameter
		theController.addToTenths(4);
		
		// Assert: that the dial has the expected value
		Odometer theOdometer = theController.getTheOdometer();
		assertEquals(4, theOdometer.getTenths());
	}
	
	@Test
	public void testShouldAddTwelveToTenthsWithRolloverToOnes() {
		// Arrange: create a controller
		OdometerController theController = new OdometerController();
		
		// Act: call the method with an appropriate parameter
		theController.addToTenths(12);
		
		// Assert: that the dial has the expected value
		Odometer theOdometer = theController.getTheOdometer();
		assertEquals(2, theOdometer.getTenths());
		assertEquals(1, theOdometer.getOnes());
	}
	
	@Test
	public void testShouldAddTwentyThreeToTenthsWithRolloverToOnes() {
		// Arrange: create a controller
		OdometerController theController = new OdometerController();
		
		// Act: call the method with an appropriate parameter
		theController.addToTenths(23);
		
		// Assert: that the dial has the expected value
		Odometer theOdometer = theController.getTheOdometer();
		assertEquals(3, theOdometer.getTenths());
		assertEquals(2, theOdometer.getOnes());
	}
	
	@Test
	public void testShouldAddOneHundredFiftySevenToTenthsWithRolloverToOnesAndTens() {
		// Arrange: create a controller
		OdometerController theController = new OdometerController();
		
		// Act: call the method with an appropriate parameter
		theController.addToTenths(157);
		
		// Assert: that the dial has the expected value
		Odometer theOdometer = theController.getTheOdometer();
		assertEquals(7, theOdometer.getTenths());
		assertEquals(5, theOdometer.getOnes());
		assertEquals(1, theOdometer.getTens());
	}
}
