/**
 * 
 */
package edu.westga.cs1301.project2.test.IPAddress;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.project2.model.IPAddress;

//import edu.westga.cs1301.project2.model.IPAddress;

/**
 * @author CS1301
 * @version Spring 2022
 *
 */
class TestConstructorFourParam {
	@Test
	void testValidConstructorFourParam() {
		// Arrange & Act: create the IP Address
		IPAddress ip = new IPAddress(1, 2, 3, 4);
		
		// Assert: that it has a non-null object
		assertNotNull(ip);
		assertEquals(1, ip.getQuartetOne(),"Testing to verify state");
		assertEquals(2, ip.getQuartetTwo(),"Testing to verify state");
		assertEquals(3, ip.getQuartetThree(),"Testing to verify state");
		assertEquals(4, ip.getQuartetFour(),"Testing to verify state");		
	}
	
	@Test
	void testValidConstructorFourParamAllAtLowerRange() {
		// Arrange & Act: create the IP Address
		IPAddress ip = new IPAddress(0, 0, 0, 0);
		
		// Assert: that it has a non-null object
		assertNotNull(ip);
		assertEquals(0, ip.getQuartetOne(),"Testing to verify state");
		assertEquals(0, ip.getQuartetTwo(),"Testing to verify state");
		assertEquals(0, ip.getQuartetThree(),"Testing to verify state");
		assertEquals(0, ip.getQuartetFour(),"Testing to verify state");		
	}
	
	@Test
	void testValidConstructorFourParamAllAtUpperRange() {
		// Arrange & Act: create the IP Address
		IPAddress ip = new IPAddress(255, 255, 255, 255);
		
		// Assert: that it has a non-null object
		assertNotNull(ip);
		assertEquals(255, ip.getQuartetOne(),"Testing to verify state");
		assertEquals(255, ip.getQuartetTwo(),"Testing to verify state");
		assertEquals(255, ip.getQuartetThree(),"Testing to verify state");
		assertEquals(255, ip.getQuartetFour(),"Testing to verify state");		
	}
	
	@Test
	void testInValidConstructorFourParamFirstArgumentBottomRange() {
		// Arrange & Act: create the IP Address
		assertThrows(IllegalArgumentException.class, ()->{
			new IPAddress(-1, 0, 0, 0);
		});
	}
	
	@Test
	void testInValidConstructorFourParamFirstArgumentUpperRange() {
		// Arrange & Act: create the IP Address
		assertThrows(IllegalArgumentException.class, ()->{
			new IPAddress(256, 0, 0, 0);
		});
	}

	@Test
	void testInValidConstructorFourParamSecondArgumentBottomRange() {
		// Arrange & Act: create the IP Address
		assertThrows(IllegalArgumentException.class, ()->{
			new IPAddress(0, -1, 0, 0);
		});
	}
	
	@Test
	void testInValidConstructorFourParamSecondArgumentUpperRange() {
		// Arrange & Act: create the IP Address
		assertThrows(IllegalArgumentException.class, ()->{
			new IPAddress(0, 256, 0, 0);
		});
	}

	
	@Test
	void testInValidConstructorFourParamThirdArgumentBottomRange() {
		// Arrange & Act: create the IP Address
		assertThrows(IllegalArgumentException.class, ()->{
			new IPAddress(0, 0, -1, 0);
		});
	}
	
	@Test
	void testInValidConstructorFourParamThirdArgumentUpperRange() {
		// Arrange & Act: create the IP Address
		assertThrows(IllegalArgumentException.class, ()->{
			new IPAddress(0, 0, 256, 0);
		});
	}

	@Test
	void testInValidConstructorFourParamFourthArgumentBottomRange() {
		// Arrange & Act: create the IP Address
		assertThrows(IllegalArgumentException.class, ()->{
			new IPAddress(0, 0, 0, -1);
		});
	}
	
	@Test
	void testInValidConstructorFourParamFourthArgumentUpperRange() {
		// Arrange & Act: create the IP Address
		assertThrows(IllegalArgumentException.class, ()->{
			new IPAddress(0, 0, 0, 256);
		});
	}


}
