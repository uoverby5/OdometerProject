package edu.westga.cs1301.project2.test.odometerformatter;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.project2.model.Odometer;
import edu.westga.cs1301.project2.view.OdometerFormatter;

/**
 * Tests to confirm correct functionality of the
 * OdometerFormatter::formatOdometer method
 * 
 * @author CS1301
 * @version Spring 2022
 *
 */
class TestFormatOdometer {

	@Test
	public void testThrowsExceptionForNullParameter() {
		// Arrange: create an OdometerFormatter object
		OdometerFormatter theFormatter = new OdometerFormatter();

		// Arrange, Act & Assert: assert that calling formatOdometer and passing it
		// null throws an IllegalArgumentException
		assertThrows(IllegalArgumentException.class, () -> {
			String result = theFormatter.formatOdometer(null);
		});
	}

	@Test
	public void testLowestOdometerValue() {
		// Arrange: create an OdometerFormatter object
		OdometerFormatter theFormatter = new OdometerFormatter();
		Odometer theOdometer = new Odometer(0, 0, 0);

		// Arrange: call formatOdometer
		String actual = theFormatter.formatOdometer(theOdometer);

		// Assert: that the number has been properly formatted
		assertEquals("00.0", actual);
	}

	@Test
	public void testHighestOdometerValue() {
		// Arrange: create an OdometerFormatter object
		OdometerFormatter theFormatter = new OdometerFormatter();
		Odometer theOdometer = new Odometer(9, 9, 9);

		// Arrange: call formatOdometer
		String actual = theFormatter.formatOdometer(theOdometer);

		// Assert: that the number has been properly formatted
		assertEquals("99.9", actual);
	}

	@Test
	public void testMiddleOdometerValue() {
		// Arrange: create an OdometerFormatter object
		OdometerFormatter theFormatter = new OdometerFormatter();
		Odometer theOdometer = new Odometer(2, 7, 5);

		// Arrange: call formatOdometer
		String actual = theFormatter.formatOdometer(theOdometer);

		// Assert: that the number has been properly formatted
		assertEquals("72.5", actual);
	}
}
