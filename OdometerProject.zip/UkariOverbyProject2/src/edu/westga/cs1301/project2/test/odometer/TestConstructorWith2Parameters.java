package edu.westga.cs1301.project2.test.odometer;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import edu.westga.cs1301.project2.model.Odometer;

/**
 * Tests to confirm correct functionality of the 
 * 	Odometer class 2-parameter constructor
 * 
 * @author	CS1301
 * @version	Spring 2022
 *
 */
public class TestConstructorWith2Parameters {

	@Test
	public void testShouldCreateWithZeroParamConstructor() {
		// Arrange & Act: create the Odometer object
		Odometer theOdometer = new Odometer();
		
		// Assert: that its initial values are correct
		assertEquals(0, theOdometer.getOnes());
		assertEquals(0, theOdometer.getTens());
	}

	@Test
	public void testShouldNotAllowNegativeTens() {
		// Arrange, Act, and Assert: create the Odometer object
		// with a negative tens value
		assertThrows(IllegalArgumentException.class, () -> {
			new Odometer(0, -1);
		});
	}
	
	@Test
	public void testShouldNotAllowTensOver9() {
		// Arrange, Act, and Assert: create the Odometer object
		// with a tens value over 9
		assertThrows(IllegalArgumentException.class, () -> {
			new Odometer(0, 10);
		});
	}

	@Test
	public void testShouldNotAllowNegativeOnes() {
		// Arrange, Act, and Assert: create the Odometer object
		// with a negative ones value
		assertThrows(IllegalArgumentException.class, () -> {
			new Odometer(-1, 0);
		});
	}
	
	@Test
	public void testShouldNotAllowOnesOver9() {
		// Arrange, Act, and Assert: create the Odometer object
		// with a ones value over 9
		assertThrows(IllegalArgumentException.class, () -> {
			new Odometer(10, 0);
		});
	}
	
	@Test
	public void testShouldCreateValidOdometer() {
		// Arrange & Act: create the Odometer object
		Odometer theOdometer = new Odometer(3, 9);
		
		// Assert: that its initial values are correct
		assertEquals(9, theOdometer.getTens());
		assertEquals(3, theOdometer.getOnes());
	}
}
