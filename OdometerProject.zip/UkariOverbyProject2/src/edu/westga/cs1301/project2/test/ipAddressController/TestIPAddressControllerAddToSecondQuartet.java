package edu.westga.cs1301.project2.test.ipAddressController;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.project2.controller.IPAddressController;
import edu.westga.cs1301.project2.model.IPAddress;

class TestIPAddressControllerAddToSecondQuartet {
	@Test
	public void testShouldNotAllowAddingNegativeNumber() {
		// Arrange: create a controller
		IPAddressController theController = new IPAddressController();
		
		// Act & Assert: call addToSecondQuartet with a negative value
		// and assert it throws an exception
		assertThrows(IllegalArgumentException.class, () -> {
			theController.addToSecondQuartet(-1);
		});
	}
	
	@Test
	public void testShouldAddZeroToSecondSetNoChange() {
		// Arrange: create a controller
		IPAddressController theController = new IPAddressController();
		
		// Act: call the method with an appropriate parameter
		theController.addToSecondQuartet(0);
		
		// Assert: that the dial has the expected value
		IPAddress theIPAddress = theController.getTheAddress();
		assertEquals(0, theIPAddress.getQuartetTwo());
	}
	
	@Test
	public void testShouldAddOneToSecondSetNoRollover() {
		// Arrange: create a controller
		IPAddressController theController = new IPAddressController();
		
		// Act: call the method with an appropriate parameter
		theController.addToSecondQuartet(1);
		
		// Assert: that the dial has the expected value
		IPAddress theIPAddress = theController.getTheAddress();
		assertEquals(1, theIPAddress.getQuartetTwo());
	}
	
	@Test
	public void testShouldAddFourToSecondSetNoRollover() {
		// Arrange: create a controller
		IPAddressController theController = new IPAddressController();
		
		// Act: call the method with an appropriate parameter
		theController.addToSecondQuartet(4);
		
		// Assert: that the dial has the expected value
		IPAddress theIPAddress = theController.getTheAddress();
		assertEquals(4, theIPAddress.getQuartetTwo());
	}
	
	@Test
	public void testShouldAdd256ToSecondSetWithRolloverToFirst() {
		// Arrange: create a controller
		IPAddressController theController = new IPAddressController();
		
		// Act: call the method with an appropriate parameter
		theController.addToSecondQuartet(256);
		
		// Assert: that the dial has the expected value
		IPAddress theIPAddress = theController.getTheAddress();
		assertEquals(0, theIPAddress.getQuartetTwo());
		assertEquals(1, theIPAddress.getQuartetThree());
	}
	@Test
	public void testShouldAdd513ToSecondSetWithRolloverToFirstTwoTimes() {
		// Arrange: create a controller
		IPAddressController theController = new IPAddressController();
		
		// Act: call the method with an appropriate parameter
		theController.addToSecondQuartet(513);
		
		// Assert: that the dial has the expected value
		IPAddress theIPAddress = theController.getTheAddress();
		assertEquals(1, theIPAddress.getQuartetTwo());
		assertEquals(2, theIPAddress.getQuartetThree());
	}
	
}
