package edu.westga.cs1301.project2.test.odometercontroller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import edu.westga.cs1301.project2.controller.OdometerController;

/**
 * Tests to confirm correct functionality of the OdometerController constructor
 * 
 * @author	CS1301
 * @version	Spring 2022
 *
 */
public class TestConstructor {

	@Test
	public void testShouldCreateOdometerController() {
		// Arrange & Act: create the controller
		OdometerController theController = new OdometerController();
		
		// Assert: that it has a non-null object
		assertNotNull(theController.getTheOdometer());
	}
}
