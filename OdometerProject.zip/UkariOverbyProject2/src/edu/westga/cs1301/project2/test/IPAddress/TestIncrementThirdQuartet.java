package edu.westga.cs1301.project2.test.IPAddress;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.project2.model.IPAddress;

class TestIncrementThirdQuartet {
	@Test
	public void testShouldIncrementThirdQuartetFrom0() {
		// Arrange: create an IPAddress with the appropriate tens dial
		IPAddress theIPAddress = new IPAddress(0, 0, 0, 0);
		
		// Act: increment the tens dial
		theIPAddress.incrementThirdQuartet();
		
		// Assert: that the actual value matches the expected value
		assertEquals(1, theIPAddress.getQuartetThree(), "Testing the increment");
	}

	@Test
	public void testShouldIncrementThirdQuartetFrom7() {
		// Arrange: create an IPAddress with the appropriate tens dial
		IPAddress theIPAddress = new IPAddress(7, 7, 7, 7);
		
		// Act: increment the tens dial
		theIPAddress.incrementThirdQuartet();
		
		// Assert: that the actual value matches the expected value
		assertEquals(8, theIPAddress.getQuartetThree(), "Testing the increment");
	}
	
	@Test
	public void testShouldIncrementThirdQuartet257Times() {
		// Arrange: create an IPAddress with the appropriate tens dial
		IPAddress theIPAddress = new IPAddress(0, 0, 0, 0);
		
		// Act: increment the tens dial
		for (int counter = 0; counter < 257; counter++) {
			theIPAddress.incrementThirdQuartet();
		}
		
		// Assert: that the actual value matches the expected value
		assertEquals(1, theIPAddress.getQuartetThree(), "Testing the increment");
	}
}
