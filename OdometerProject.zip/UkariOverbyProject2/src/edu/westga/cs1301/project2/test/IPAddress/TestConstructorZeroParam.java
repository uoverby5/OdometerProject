package edu.westga.cs1301.project2.test.IPAddress;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.project2.model.IPAddress;

//import edu.westga.cs1301.project2.model.IPAddress;

class TestConstructorZeroParam {

	@Test
	void testValidConstructorZeroParam() {
		// Arrange & Act: create the IP Address
		IPAddress ip = new IPAddress();
		
		// Assert: that it has a non-null object
		assertNotNull(ip);
		assertEquals(0, ip.getQuartetOne(),"Testing to verify state");
		assertEquals(0, ip.getQuartetTwo(),"Testing to verify state");
		assertEquals(0, ip.getQuartetThree(),"Testing to verify state");
		assertEquals(0, ip.getQuartetFour(),"Testing to verify state");		
	}
	
}
