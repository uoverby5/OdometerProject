package edu.westga.cs1301.project2.test.ipAddressController;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.project2.controller.IPAddressController;
import edu.westga.cs1301.project2.model.IPAddress;

class TestIPAddressControllerAddToFirstQuartet {
	@Test
	public void testShouldNotAllowAddingNegativeNumber() {
		// Arrange: create a controller
		IPAddressController theController = new IPAddressController();
		
		// Act & Assert: call addToFirstQuartet with a negative value
		// and assert it throws an exception
		assertThrows(IllegalArgumentException.class, () -> {
			theController.addToFirstQuartet(-1);
		});
	}
	
	@Test
	public void testShouldAddZeroToFirstSetNoChange() {
		// Arrange: create a controller
		IPAddressController theController = new IPAddressController();
		
		// Act: call the method with an appropriate parameter
		theController.addToFirstQuartet(0);
		
		// Assert: that the dial has the expected value
		IPAddress theIPAddress = theController.getTheAddress();
		assertEquals(0, theIPAddress.getQuartetOne());
	}
	
	@Test
	public void testShouldAddOneToFirstSetNoRollover() {
		// Arrange: create a controller
		IPAddressController theController = new IPAddressController();
		
		// Act: call the method with an appropriate parameter
		theController.addToFirstQuartet(1);
		
		// Assert: that the dial has the expected value
		IPAddress theIPAddress = theController.getTheAddress();
		assertEquals(1, theIPAddress.getQuartetOne());
	}
	
	@Test
	public void testShouldAddFourToFirstSetNoRollover() {
		// Arrange: create a controller
		IPAddressController theController = new IPAddressController();
		
		// Act: call the method with an appropriate parameter
		theController.addToFirstQuartet(4);
		
		// Assert: that the dial has the expected value
		IPAddress theIPAddress = theController.getTheAddress();
		assertEquals(4, theIPAddress.getQuartetOne());
	}
	
	@Test
	public void testShouldAdd256ToFirstSetWithNoRollover() {
		// Arrange: create a controller
		IPAddressController theController = new IPAddressController();
		
		// Act: call the method with an appropriate parameter
		theController.addToFirstQuartet(256);
		
		// Assert: that the dial has the expected value
		IPAddress theIPAddress = theController.getTheAddress();
		assertEquals(0, theIPAddress.getQuartetOne());
	}
	@Test
	public void testShouldAdd255ToFirstSetWithNoRollover() {
		// Arrange: create a controller
		IPAddressController theController = new IPAddressController();
		
		// Act: call the method with an appropriate parameter
		theController.addToFirstQuartet(255);
		
		// Assert: that the dial has the expected value
		IPAddress theIPAddress = theController.getTheAddress();
		assertEquals(255, theIPAddress.getQuartetOne());
	}
}
