package edu.westga.cs1301.project2.test.odometercontroller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.project2.controller.OdometerController;
import edu.westga.cs1301.project2.model.Odometer;

class TestSubstractFromTens {

	@Test
	public void testShouldNotAllowSubtractingNegativeNumber() {
		// ARRANGE
		OdometerController theController = new OdometerController();
		
		// ACT && ASSERT
		assertThrows(IllegalArgumentException.class, () -> {
			theController.subtractFromTens(-1);
		});
	}
	
	@Test
	public void testShouldSubtractZeroFromTens() {
		// Arrange: create a controller
		OdometerController theController = new OdometerController();
		
		// Act: call the method with an appropriate parameter
		theController.subtractFromTens(0);
		
		// Assert: that the dial has the expected value
		Odometer theOdometer = theController.getTheOdometer();
		assertEquals(0, theOdometer.getTens());
	}
	
	/*
	 * @Test public void testShouldSubtractOneFromTens() { // Arrange: create a
	 * controller OdometerController theController = new OdometerController();
	 * 
	 * // Act: call the method with an appropriate parameter
	 * theController.subtractFromTens(1);
	 * 
	 * // Assert: that the dial has the expected value Odometer theOdometer =
	 * theController.getTheOdometer(); assertEquals(1, theOdometer.getTens()); }
	 */
	
	
	

}
