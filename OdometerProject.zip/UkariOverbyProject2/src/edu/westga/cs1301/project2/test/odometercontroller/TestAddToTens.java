package edu.westga.cs1301.project2.test.odometercontroller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.project2.controller.OdometerController;
import edu.westga.cs1301.project2.model.Odometer;

/**
 * Tests to confirm correct functionality of adding to the
 * 	odometer's tens dial
 * 
 * @author	CS1301
 * @version	Spring 2022
 *
 */
public class TestAddToTens {

	@Test
	public void testShouldNotAllowAddingNegativeNumber() {
		// Arrange: create a controller
		OdometerController theController = new OdometerController();
		
		// Act & Assert: call addToTens with a negative value
		// and assert it throws an exception
		assertThrows(IllegalArgumentException.class, () -> {
			theController.addToTens(-1);
		});
	}
	
	@Test
	public void testShouldAddZeroToTens() {
		// Arrange: create a controller
		OdometerController theController = new OdometerController();
		
		// Act: call the method with an appropriate parameter
		theController.addToTens(0);
		
		// Assert: that the dial has the expected value
		Odometer theOdometer = theController.getTheOdometer();
		assertEquals(0, theOdometer.getTens());
	}
	
	@Test
	public void testShouldAddOneToTens() {
		// Arrange: create a controller
		OdometerController theController = new OdometerController();
		
		// Act: call the method with an appropriate parameter
		theController.addToTens(1);
		
		// Assert: that the dial has the expected value
		Odometer theOdometer = theController.getTheOdometer();
		assertEquals(1, theOdometer.getTens());
	}
	
	@Test
	public void testShouldAddFourToTens() {
		// Arrange: create a controller
		OdometerController theController = new OdometerController();
		
		// Act: call the method with an appropriate parameter
		theController.addToTens(4);
		
		// Assert: that the dial has the expected value
		Odometer theOdometer = theController.getTheOdometer();
		assertEquals(4, theOdometer.getTens());
	}
	
	@Test
	public void testShouldAddTwelveToTens() {
		// Arrange: create a controller
		OdometerController theController = new OdometerController();
		
		// Act: call the method with an appropriate parameter
		theController.addToTens(12);
		
		// Assert: that the dial has the expected value
		Odometer theOdometer = theController.getTheOdometer();
		assertEquals(2, theOdometer.getTens());
	}
}
