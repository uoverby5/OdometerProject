package edu.westga.cs1301.project2.test.odometercontroller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import edu.westga.cs1301.project2.controller.OdometerController;
import edu.westga.cs1301.project2.model.Odometer;

/**
 * Tests to confirm correct functionality of adding to the
 * 	odometer's ones dial
 * 
 * @author	CS1301
 * @version	Spring 2022
 *
 */
public class TestAddToOnes {

	@Test
	public void testShouldNotAllowAddingNegativeNumber() {
		// Arrange: create a controller
		OdometerController theController = new OdometerController();
		
		// Act & Assert: call addToOnes with a negative value
		// and assert it throws an exception
		assertThrows(IllegalArgumentException.class, () -> {
			theController.addToOnes(-1);
		});
	}
	
	@Test
	public void testShouldAddZeroToOnes() {
		// Arrange: create a controller
		OdometerController theController = new OdometerController();
		
		// Act: call the method with an appropriate parameter
		theController.addToOnes(0);
		
		// Assert: that the dial has the expected value
		Odometer theOdometer = theController.getTheOdometer();
		assertEquals(0, theOdometer.getOnes());
	}
	
	@Test
	public void testShouldAddOneToOnes() {
		// Arrange: create a controller
		OdometerController theController = new OdometerController();
		
		// Act: call the method with an appropriate parameter
		theController.addToOnes(1);
		
		// Assert: that the dial has the expected value
		Odometer theOdometer = theController.getTheOdometer();
		assertEquals(1, theOdometer.getOnes());
	}
	
	@Test
	public void testShouldAddFourToOnes() {
		// Arrange: create a controller
		OdometerController theController = new OdometerController();
		
		// Act: call the method with an appropriate parameter
		theController.addToOnes(4);
		
		// Assert: that the dial has the expected value
		Odometer theOdometer = theController.getTheOdometer();
		assertEquals(4, theOdometer.getOnes());
	}
	
	@Test
	public void testShouldAddTwelveToOnesWithRolloverToTens() {
		// Arrange: create a controller
		OdometerController theController = new OdometerController();
		
		// Act: call the method with an appropriate parameter
		theController.addToOnes(12);
		
		// Assert: that the dial has the expected value
		Odometer theOdometer = theController.getTheOdometer();
		assertEquals(2, theOdometer.getOnes());
		assertEquals(1, theOdometer.getTens());
	}
	
	@Test
	public void testShouldAddTwentyThreeToOnesWithRolloverToTens() {
		// Arrange: create a controller
		OdometerController theController = new OdometerController();
		
		// Act: call the method with an appropriate parameter
		theController.addToOnes(23);
		
		// Assert: that the dial has the expected value
		Odometer theOdometer = theController.getTheOdometer();
		assertEquals(3, theOdometer.getOnes());
		assertEquals(2, theOdometer.getTens());
	}
}
