/**
 * 
 */
package edu.westga.cs1301.project2.test.ipAddressFormatter;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.project2.model.IPAddress;
import edu.westga.cs1301.project2.view.IPAddressFormatter;

/**
 * This class can be used to format an ip address
 * 
 * @author	CS1301
 * @version	Spring 2022
 *
 */
class TestFormatIPAddress {
	@Test
	public void testThrowsExceptionForNullParameter() {
		// Arrange: create an IPAddressFormatter object
		IPAddressFormatter theFormatter = new IPAddressFormatter();

		// Arrange, Act & Assert: assert that calling formatIPAddress and passing it
		// null throws an IllegalArgumentException
		assertThrows(IllegalArgumentException.class, () -> {
			String result = theFormatter.formatIPAddress(null);
		});
	}

	@Test
	public void testLowestIPAddressValue() {
		// Arrange: create an IPAddressFormatter object
		IPAddressFormatter theFormatter = new IPAddressFormatter();
		IPAddress theIPAddress = new IPAddress(0, 0, 0, 0);

		// Arrange: call formatIPAddress
		String actual = theFormatter.formatIPAddress(theIPAddress);

		// Assert: that the number has been properly formatted
		assertEquals("0.0.0.0", actual);
	}

	@Test
	public void testHighestIPAddressValue() {
		// Arrange: create an IPAddressFormatter object
		IPAddressFormatter theFormatter = new IPAddressFormatter();
		IPAddress theIPAddress = new IPAddress(255, 255, 255, 255);

		// Arrange: call formatIPAddress
		String actual = theFormatter.formatIPAddress(theIPAddress);

		// Assert: that the number has been properly formatted
		assertEquals("255.255.255.255", actual);
	}

	@Test
	public void testMiddleIPAddressValue() {
		// Arrange: create an IPAddressFormatter object
		IPAddressFormatter theFormatter = new IPAddressFormatter();
		IPAddress theIPAddress = new IPAddress(192, 168, 5, 86);

		// Arrange: call formatIPAddress
		String actual = theFormatter.formatIPAddress(theIPAddress);

		// Assert: that the number has been properly formatted
		assertEquals("192.168.5.86", actual);
	}


}
