package edu.westga.cs1302.casino.game;

/**
 * The enum GameType.
 * 
 * @author CS1302
 * @version Spring 2023
 */
public enum GameType {

	BLACKJACK, BACCARAT

}
