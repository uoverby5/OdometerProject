package edu.westga.cs1302.casino.game;

import java.util.ArrayList;

import edu.westga.cs1302.casino.model.Card;
import edu.westga.cs1302.casino.model.Deck;
import edu.westga.cs1302.casino.model.HumanPlayer;
import edu.westga.cs1302.casino.model.Player;
import edu.westga.cs1302.casino.resources.ExceptionMessages;
import edu.westga.cs1302.casino.resources.UI;

/** The abstract game class.
 * 
 * @author Ukari Overby
 * @version Spring 2023
 *
 */
public abstract class Game {
	public static final String INVALID_TIE_AMOUNT = "Ties must not be negative";
	public static final int HUMAN_PLAYER_MONEY = 100;
	public static final int NUM_CARDS_DEALT_INITIALLY = 2;
	
	private Deck deck;
	private Player dealer;
	private HumanPlayer humanPlayer;

	private int pot;
	private int dealerWins;
	private int humanWins;
	private int ties;

	private String message;
	
	/**
	 * Creates a default game object
	 * 
	 * @precondition none.
	 * @postcondition none.
	 */
	public Game() {
		this.dealerWins = 0;
		this.humanWins = 0;
		this.ties = 0;
		this.dealer = new Player();
		this.humanPlayer = new HumanPlayer(HUMAN_PLAYER_MONEY);
		this.startNewRound();
	}
	
	/**
	 * Starts a new round of the game.
	 * 
	 * @precondition none.
	 * @postcondition deck is instantiated and shuffled && getPot() == 0 && the
	 *                players have no cards
	 */
	public void startNewRound() {
		this.deck = new Deck();
		this.deck.shuffle();
		this.pot = 0;
		this.dealer.emptyHand();
		this.humanPlayer.emptyHand();
		
	}
	
	/**
	 * Sets the message of this game.
	 * 
	 * @precondition message != null && !message.isEmpty()
	 * @postcondition none
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		if (message == null) {
			throw new IllegalArgumentException(ExceptionMessages.NULL_GAME_MESSAGE);
		}
		if (message.isEmpty()) {
			throw new IllegalArgumentException(ExceptionMessages.EMPTY_GAME_MESSAGE);
		}
		this.message = message;
	}
	
	/**
	 * Gets the message of this game.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the message
	 */
	public String getMessage() {
		return this.message;
	}
	
	/**Gets the dealer wins.
	 * 
	 * @precondition none.
	 * @postcondition none.
	 * 
	 * @return the number of dealer wins.
	 */
	public int getDealerWins() {
		return this.dealerWins;
	}

	/**Sets the dealers win.
	 * 
	 * @precondition dealerWins >= 0
	 * @postcondition none.
	 * 
	 * @param dealerWins - the number of dealer wins
	 */
	public void setDealerWins(int dealerWins) {
		this.dealerWins = dealerWins;
	}

	/**Gets the human wins.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the number of human wins.
	 */
	public int getHumanWins() {
		return this.humanWins;
	}

	/**Sets the human wins.
	 * 
	 * @precondition humanWins >= 0
	 * @postcondition none
	 * 
	 * @param humanWins - the number of human wins
	 */
	public void setHumanWins(int humanWins) {
		this.humanWins = humanWins;
	}
	
	/**Gets the ties.
	 * 
	 * @precondition none.
	 * @postcondition none.
	 * 
	 * @return the number of ties.
	 */
	public int getTies() {
		return this.ties;
	}
	
	/**Sets the number of ties
	 * 
	 * @precondition ties >= 0
	 * 
	 * @param ties - the number of ties
	 */
	public void setTies(int ties) {
		if (ties < 0) {
			throw new IllegalArgumentException(INVALID_TIE_AMOUNT);
		}
		
		this.ties = ties;
	}
	
	/**
	 * Gets the dealer of this game.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the dealer
	 */
	public Player getDealer() {
		return this.dealer;
	}
	
	/**
	 * Gets the human player of this game.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the human player
	 */
	public HumanPlayer getHumanPlayer() {
		return this.humanPlayer;
	}
	
	/**
	 * Gets the pot of this game.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the pot
	 */
	public int getPot() {
		return this.pot;
	}

	/**
	 * Sets the pot for this game based on the specified bet.
	 * 
	 * @precondition pot > 0
	 * @postcondition getPot() == 2 * bet
	 * @param bet the amount bet by the player
	 */
	public void setPot(int bet) {
		if (bet <= 0) {
			throw new IllegalArgumentException(ExceptionMessages.INVALID_AMOUNT);
		}
		this.humanPlayer.bet(bet);
		this.pot = 2 * bet;
	}
	
	/**
	 * Returns the statistics of this game.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the stats as a string
	 */
	public String getStats() {
		return "You: " + this.humanWins + System.lineSeparator() + "Dealer: " + this.dealerWins + System.lineSeparator()
				+ "Ties: " + this.ties;
	}
	
	/**
	 * Deals a card to the specified player, form the top of the deck.
	 * 
	 * @precondition none
	 * @postcondition top card from deck goes to the specified player
	 * @param player the specified player
	 */
	public void dealCardTo(Player player) {
		if (player == null) {
			throw new IllegalArgumentException(ExceptionMessages.NULL_PLAYER);
		}
		Card card = this.deck.draw();
		player.addCard(card);
	}

	/**
	 * Deals the initial hands to the players.
	 * 
	 * @precondition none
	 * @postcondition players are dealt two cards and the human player gets first
	 *                card
	 */
	public void dealHands() {
		for (int count = 0; count < NUM_CARDS_DEALT_INITIALLY; count++) {
			this.dealCardTo(this.humanPlayer);
			this.dealCardTo(this.dealer);
		}
	}
	
	/**
	 * Returns the player's hand of cards.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @param player the specified player
	 * @return the dealer's cards
	 */
	public ArrayList<Card> getHand(Player player) {
		if (player == null) {
			throw new IllegalArgumentException(ExceptionMessages.NULL_PLAYER);
		}
		return player.getHand();
	}

	/**
	 * Record tie round.
	 * 
	 * @precondition message != null && !message.isEmpty()
	 * @postcondition message is set, the player gets half the pot (i.e., their
	 *                initial bet) and number of ties is incremented
	 * @param message the message to display
	 */
	public void registerTieRound(String message) {
		this.setMessage(message);
		this.humanPlayer.receive(this.getPot() / 2);
		this.ties++;
	}
	
	/**
	 * Record humanPlayer win.
	 * 
	 * @precondition message != null && !message.isEmpty()
	 * @postcondition message is set, the player gets the pot or twice the pot if
	 *                has natural, and the number of human player wins is
	 *                incremented
	 * @param message the message to display
	 */
	public void humanPlayerWinsRound(String message) {
		this.setMessage(message);
		this.humanWins++;
		if (this.isNatural(this.humanPlayer.getHand())) {
			this.humanPlayer.receive(2 * this.getPot());
		} else {
			this.humanPlayer.receive(this.getPot());
		}
	}

	/**
	 * Record dealer win.
	 * 
	 * @precondition message != null && !message.isEmpty()
	 * @postcondition message is set and the number
	 * @param message the message to display
	 */
	public void dealerWinsRound(String message) {
		if (this.humanPlayer.getMoney() == 0) {
			this.setMessage(message + System.lineSeparator() + UI.GAME_OVER);
		} else {
			this.setMessage(message);
			this.dealerWins++;
		}
	}

	/**
	 * Checks if player has a natural hand.
	 * 
	 * @precondition player != null
	 * @postcondition none
	 * @param player the specified player
	 * @return true if the player's hand is a natural one, false otherwise
	 */
	public boolean hasNatural(Player player) {
		if (player == null) {
			throw new IllegalArgumentException(ExceptionMessages.NULL_PLAYER);
		}
		ArrayList<Card> hand = player.getHand();
		return this.isNatural(hand);
	}
	
	/** Checks if the player has a natural hand.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @param hand - the players cards in hand
	 * @return true if the hand is natural, false otherwise
	 */
	abstract boolean isNatural(ArrayList<Card> hand);
	
	/** Gets the score of the players hand.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @param hand - the cards in the players hand.
	 * 
	 * @return the score of the player
	 */
	public abstract int getScore(ArrayList<Card> hand);
	
	/**Player wants an additional card from the deck
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return true if player gets another card, false otherwise.
	 */
	public abstract boolean hit();
	
	/**
	 * The player stands and now the dealer will play their turn and the game will
	 * reach a resolution.
	 * 
	 * @precondition player has decided to stand
	 * @postcondition game concluded
	 */
	public abstract void humanPlayerStands();

}
