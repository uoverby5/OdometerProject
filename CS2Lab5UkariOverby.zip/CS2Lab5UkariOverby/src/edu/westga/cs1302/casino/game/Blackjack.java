package edu.westga.cs1302.casino.game;

import java.util.ArrayList;

import edu.westga.cs1302.casino.model.Card;
import edu.westga.cs1302.casino.model.HumanPlayer;
import edu.westga.cs1302.casino.model.Player;
import edu.westga.cs1302.casino.model.Rank;
import edu.westga.cs1302.casino.resources.UI;

/** The Blackjack Class
 * 
 * @author Ukari Overby
 * @version Spring 2023
 *
 */
public class Blackjack extends Game {
	
	public static final int TWENTY_ONE = 21;
	public static final int DEALER_THRESHOLD = 17;
	
	/**
	 * Instantiates and starts a new game of Blackjack.
	 * 
	 * @precondition none
	 * @postcondition a new game is started
	 */
	public Blackjack() {
		super();
	}
	
	/**
	 * Starts a new round of the game.
	 * 
	 * @precondition none
	 * @postcondition deck is instantiated and shuffled && getPot() == 0 && the
	 *                players have no cards
	 */
	@Override
	public void startNewRound() {
		super.startNewRound();
		this.setMessage(GameType.BLACKJACK.toString());	
	}

	@Override
	boolean isNatural(ArrayList<Card> hand) {
		if (hand.size() != 2) {
			return false;
		}

		Card cardOne = hand.get(0);
		Card cardTwo = hand.get(1);

		if (cardOne.getRank() == Rank.ACE.getValue() && cardTwo.isFaceCard()) {
			return true;
		} else if (cardTwo.getRank() == Rank.ACE.getValue() && cardOne.isFaceCard()) {
			return true;
		}

		return false;
	}

	@Override
	public int getScore(ArrayList<Card> hand) {
		int score = 0;
		int aceCount = 0;
		
		for (Card currCard : hand) {
			if (currCard.getRank() == Rank.ACE.getValue()) {
				aceCount++;
			}
			
			if (currCard.getRank() != Rank.ACE.getValue() && currCard.getRank() <= 10) {
				score += currCard.getRank();
			} else if (currCard.getRank() != Rank.ACE.getValue()) {
				score += 10;	
			} 
		}
		
		 if (aceCount == 1 && score <= 10) {
			score += 11;
		} else if (aceCount > 1) {
			score += aceCount;
		} else if (aceCount == 1 && score > 10) {
			score++;
		}
		 
		 return score;
	}

	@Override
	public boolean hit() {
		Player human = this.getHumanPlayer();
		int humanScore = this.getScore(human.getHand());
		
		this.dealCardTo(human);
		if (humanScore > 21) {
			this.dealerWinsRound("Bust - you lose.");
			return false;
		} else {
			return true;
		}
	}

	@Override
	public void humanPlayerStands() {
		Player dealer = this.getDealer();
		int dealerScore = this.getScore(dealer.getHand());
		HumanPlayer human = this.getHumanPlayer();
		int humanScore = this.getScore(human.getHand());
		int ties = this.getTies();
		int dealerWins = this.getDealerWins();
		int humanWins = this.getHumanWins();
		
		if (dealerScore <= DEALER_THRESHOLD) {
			this.dealCardTo(dealer);
		}
		if (this.hasNatural(human) && this.hasNatural(dealer)) {
			this.setMessage(UI.STANDOFF_NATURAL);
			int playerBet = this.getPot() / 2;
			human.receive(playerBet);
			ties++;
		} else if (this.hasNatural(human)) {
			this.setMessage(UI.PLAYER_WINS_DOUBLE); 
			int winnings = this.getPot() * 2;
			human.receive(winnings);
			humanWins++;
			
		} else if (this.hasNatural(dealer)) {
			this.setMessage(UI.DEALER_WINS_NATURAL);
			dealerWins++;
			
		} else if (humanScore == TWENTY_ONE && dealerScore == TWENTY_ONE) {
			this.setMessage(UI.STANDOFF); 
			int playerBet = this.getPot() / 2;
			human.receive(playerBet);
			ties++;
			
		} else if (humanScore == TWENTY_ONE && dealerScore != TWENTY_ONE) {
			humanWins = this.playerWins(human, humanWins);
			
		} else if (dealerScore == TWENTY_ONE && humanScore != TWENTY_ONE) {
			dealerWins = this.dealerWins(dealerWins);
			
		} else if (dealerScore > TWENTY_ONE) {
			this.setMessage(UI.DEALER_BUSTS);
			int winnings = this.getPot();
			human.receive(winnings);
			humanWins++;
			
		} else if (humanScore > TWENTY_ONE) {
			this.setMessage(UI.PLAYER_BUSTS);
			dealerWins++;
			
		} else if (humanScore > dealerScore) {
			humanWins = this.playerWins(human, humanWins);
			
		} else if (dealerScore > humanScore) {
			dealerWins = this.dealerWins(dealerWins);
			
		} else if (humanScore == dealerScore) {
			this.ties(ties);
		}
				
	}

	private void ties(int ties) {
		this.setMessage(UI.TIE);
		ties++;
	}

	private int dealerWins(int dealerWins) {
		this.setMessage(UI.DEALER_WINS);
		return dealerWins++;
	}

	private int playerWins(HumanPlayer human, int humanWins) {
		this.setMessage(UI.PLAYER_WINS);
		int winnings = this.getPot();
		human.receive(winnings);
		return humanWins++;
	}
	
}
