package edu.westga.cs1302.casino.model;

/**
 * The enum Suit.
 * 
 * @author CS1302
 * @version Spring 2023
 */
public enum Suit {

	SPADES, HEARTS, DIAMONDS, CLUBS

}
